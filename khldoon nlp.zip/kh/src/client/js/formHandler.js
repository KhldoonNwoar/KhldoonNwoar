import axios from "axios";
import {isValidUrl} from "./checkURL"

const input = document.querySelector("urlForm")
const form = document.querySelector("form")
const error = document.querySelector("error")
const name = document.querySelector("name")
const news = document.querySelector("news")
const weather = document.querySelector("weather")
const sentiment = document.querySelector("sentiment")
const FormResults = document.querySelector("#Form_Results");
const handleSubmit = document.querySelector("handleSubmit");


const Form_Results = (sample) => {
    error.style.display = 'none';
    results.forEach(result => {
        result.style.display = 'none';
    })
}

// Attach event listener after the document is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("urlForm").addEventListener("submit", async (event) => {
        event.preventDefault();

        const inputElement = document.getElementById("url");
        const url = inputElement.value;

        if (!isValidUrl(url)) {
            alert("Please enter a valid URL");
            return;
        }

        try {
            const response = await fetch("http://localhost:8081/api", { 
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ url })
            });
            const data = await response.json();

            // Display the result in the "result" div
            const resultElement = document.getElementById("resultElement");
            resultElement.innerHTML = `
                <p>Name: ${data.sample.name}</p>
                <p>News: ${data.sample.news}</p>
                <p>Weather: ${data.sample.weather}</p>
                <p>Joke: ${data.sample.joke}</p>
                <p>Sentiment: ${data.sample.sentiment}</p>
                <p>Status Code: ${data.code}</p>
            `;
        } catch (error) {
            console.error("Error:", error);
        }
    });
});

export { handleSubmit,
    Form_Results
}