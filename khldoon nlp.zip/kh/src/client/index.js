import { handleSubmit } from './js/formHandler.js'


alert("khldoon")

export { handleSubmit }

import './styles/base.scss'
import './styles/header.scss'
import './styles/footer.scss'
import './styles/form.scss'
import './styles/resets.scss'