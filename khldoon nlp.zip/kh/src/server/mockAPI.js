const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { handleSubmit } = require("./mockAPI"); // Make sure to use handleSubmit instead of submit
const app = express();
const port = 8081;

app.use(cors());
app.use(express.static('dist'));
app.use(express.json());
dotenv.config();

const MEAN_CLOUD_API_KEY = process.env.API_KEY;

app.get('/', function (req, res) {
    res.sendFile('index.html'); // Use res.sendFile to serve the HTML file
});

app.post("/", async (req, res) => {
    // 1. GET the url from the request body
    const url = req.body.URI;
    
    try {
        // 2. Fetch Data from API by sending the url and the key
        const analysis = await handleSubmit(url, MEAN_CLOUD_API_KEY);
        const { code, msg, sample } = analysis;
        
        // Send response based on the analysis result
        res.send({ msg: msg, code: code, sample: sample });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send({ msg: "Internal Server Error", code: 500 });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
