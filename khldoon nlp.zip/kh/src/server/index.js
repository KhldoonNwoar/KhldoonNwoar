const axios = require("axios");

const meaningCloudApiUrl = "https://api.meaningcloud.com/sentiment-2.1";

const handleSubmit = async (url, key) => {
    try {
        const response = await axios.get(`${meaningCloudApiUrl}?key=${key}&url=${url}&lang=en`);
        const { code } = response.data.status;

        if (code === 200) {
            return handleError(code, "Please enter a valid URL");
        } else if (code === 500) {
            return handleError(code, response.data.status.msg);
        }

        return successResponse(response.data, code);
    } catch (error) {
        return handleError(500, "An error occurred while fetching data from MeaningCloud");
    }
};

const handleError = (code, msg) => {
    return {
        code: code,
        msg: msg
    };
};

const successResponse = (data, code) => {
    const { name, news, weather, joke, sentiment } = data;
    const sample = {
        name: name,
        news: news,
        weather: weather,
        joke: joke,
        sentiment: sentiment
    };
    return {
        sample: sample,
        status: code
    };
};

module.exports = {
    handleSubmit
};
